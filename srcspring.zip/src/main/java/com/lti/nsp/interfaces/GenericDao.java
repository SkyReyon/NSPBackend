package com.lti.nsp.interfaces;

import com.lti.nsp.entity.RegistrationDetails;

public interface GenericDao {

	public Object add(Object obj);
	//public Object fetchById(Class classname, Object sId);
		
}
