package com.lti.nsp.dto;

public class InstituteData {

	private String instCode;
	private String institueName;
	public String getInstCode() {
		return instCode;
	}
	public void setInstCode(String instCode) {
		this.instCode = instCode;
	}
	public String getInstitueName() {
		return institueName;
	}
	public void setInstitueName(String institueName) {
		this.institueName = institueName;
	}

	
}
