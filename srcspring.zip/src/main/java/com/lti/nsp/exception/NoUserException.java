package com.lti.nsp.exception;

public class NoUserException extends Exception{


	public NoUserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
